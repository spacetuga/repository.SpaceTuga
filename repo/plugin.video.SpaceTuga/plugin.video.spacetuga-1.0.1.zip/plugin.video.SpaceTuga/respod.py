import xbmcaddon
import base64

MainBase = base64.b64decode('aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvaTRYREt0MFQ=')
addon = xbmcaddon.Addon('plugin.video.spacetuga')